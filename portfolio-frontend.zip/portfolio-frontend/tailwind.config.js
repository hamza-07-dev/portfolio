/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0A0E17",
        "bg-elevated": "#0F1420",
        surface: "rgba(255,255,255,0.04)",
        "surface-hover": "rgba(255,255,255,0.07)",
        border: "rgba(255,255,255,0.08)",
        text: "#F1F5F9",
        "text-muted": "#94A3B8",
        "text-dim": "#64748B",
        blue: "#3B82F6",
        purple: "#8B5CF6",
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%)",
      },
      fontFamily: {
        display: ["Space Grotesk", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px rgba(59,130,246,0.35)",
        card: "0 10px 40px rgba(0,0,0,0.35)",
      },
      borderRadius: {
        card: "20px",
      },
    },
  },
  plugins: [],
};
