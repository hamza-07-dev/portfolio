import { lazy, Suspense } from "react";
import { useSiteMode } from "./hooks/useSiteMode";
import ClassicApp from "./ClassicApp";

const ImmersiveApp = lazy(() => import("./ImmersiveApp"));

export default function App() {
  const mode = useSiteMode();

  // Avoid a flash of the wrong layout while we detect capabilities
  if (mode === "checking") {
    return <div className="min-h-screen bg-bg" />;
  }

  if (mode === "classic") {
    return <ClassicApp />;
  }

  return (
    <Suspense fallback={<div className="min-h-screen bg-bg" />}>
      <ImmersiveApp />
    </Suspense>
  );
}
