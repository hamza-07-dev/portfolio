export default function Footer() {
  return (
    <footer className="border-t border-border py-8 text-center">
      <p className="text-sm text-text-dim">
        © {new Date().getFullYear()} Hamza. Built with React, Tailwind & Three.js.
      </p>
    </footer>
  );
}
