import { useState } from "react";
import { api } from "../../lib/api";
import GlassCard from "../ui/GlassCard";
import Button from "../ui/Button";

const PROJECT_TYPES = ["SaaS Web App", "AI & Automation", "MVP Build", "Consultation"];

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", projectType: PROJECT_TYPES[0], message: "" });
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("sending");
    try {
      await api.sendContact(form);
      setStatus("sent");
      setForm({ name: "", email: "", projectType: PROJECT_TYPES[0], message: "" });
    } catch (err) {
      setStatus("error");
    }
  }

  return (
    <section id="contact" className="max-w-[1200px] mx-auto px-6 py-24">
      <span className="text-xs font-medium tracking-wider text-purple">GET IN TOUCH</span>
      <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-10">Start a Project</h2>

      <GlassCard className="max-w-xl">
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label className="text-xs text-text-muted" htmlFor="name">Full Name</label>
            <input
              id="name"
              required
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              className="w-full mt-1 px-4 py-2.5 rounded-lg bg-bg-elevated border border-border outline-none focus:border-blue/60 text-sm"
              placeholder="Your name"
            />
          </div>
          <div>
            <label className="text-xs text-text-muted" htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              required
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              className="w-full mt-1 px-4 py-2.5 rounded-lg bg-bg-elevated border border-border outline-none focus:border-blue/60 text-sm"
              placeholder="you@company.com"
            />
          </div>
          <div>
            <label className="text-xs text-text-muted">Project Focus</label>
            <div className="flex flex-wrap gap-2 mt-1.5">
              {PROJECT_TYPES.map((type) => (
                <button
                  type="button"
                  key={type}
                  onClick={() => update("projectType", type)}
                  className={`px-3 py-1.5 rounded-full text-xs transition-colors ${
                    form.projectType === type
                      ? "bg-brand-gradient text-white"
                      : "bg-bg-elevated border border-border text-text-muted"
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-text-muted" htmlFor="message">Message</label>
            <textarea
              id="message"
              required
              rows={4}
              value={form.message}
              onChange={(e) => update("message", e.target.value)}
              className="w-full mt-1 px-4 py-2.5 rounded-lg bg-bg-elevated border border-border outline-none focus:border-blue/60 text-sm resize-none"
              placeholder="Tell me about your goals and timeline…"
            />
          </div>

          <Button type="submit" disabled={status === "sending"}>
            {status === "sending" ? "Sending…" : "Send Message"}
          </Button>

          {status === "sent" && (
            <p className="text-sm text-blue">Message sent — I'll get back to you soon.</p>
          )}
          {status === "error" && (
            <p className="text-sm text-red-400">Something went wrong. Please try again.</p>
          )}
        </form>
      </GlassCard>
    </section>
  );
}
