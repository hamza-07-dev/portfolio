import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import GlassCard from "../ui/GlassCard";
import Badge from "../ui/Badge";

// Shown while the API loads, and as a safety net if it's unreachable —
// never fabricated numbers, just the real project facts.
const FALLBACK_PROJECTS = [
  {
    id: "coprogest",
    title: "COPROGEST",
    category: "SaaS · Property Management",
    description:
      "Condominium and building syndicate management platform with 6 user roles, payment integration, and incident tracking. Built as a final-year graduation project.",
    stack: ["React 18", "Laravel 11", "MySQL 8"],
    highlights: ["6 user roles", "Payment integration", "Incident tracking"],
  },
  {
    id: "pointforge",
    title: "PointForge",
    category: "Gaming · Rewards Platform",
    description:
      "Gaming rewards platform connecting a React/Vite frontend to a Laravel API.",
    stack: ["React (Vite)", "Laravel API"],
    highlights: [],
  },
];

export default function Projects() {
  const [projects, setProjects] = useState(FALLBACK_PROJECTS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getProjects()
      .then((data) => {
        if (data && data.length > 0) setProjects(data);
      })
      .catch(() => {
        // keep the fallback list — no error shown to visitors
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <section id="projects" className="max-w-[1200px] mx-auto px-6 py-24">
      <span className="text-xs font-medium tracking-wider text-blue">FEATURED PROJECTS</span>
      <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-10">Selected Work</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((project) => (
          <GlassCard
            key={project.id}
            className="group transition-transform duration-200 hover:-translate-y-1"
          >
            <span className="text-xs text-text-dim">{project.category}</span>
            <h3 className="text-xl font-semibold mt-1 mb-3">{project.title}</h3>
            <p className="text-text-muted text-sm leading-relaxed mb-4">
              {project.description}
            </p>
            {project.highlights?.length > 0 && (
              <ul className="text-sm text-text-muted mb-4 space-y-1">
                {project.highlights.map((h) => (
                  <li key={h} className="flex items-center gap-2">
                    <span className="w-1 h-1 rounded-full bg-blue" />
                    {h}
                  </li>
                ))}
              </ul>
            )}
            <div className="flex flex-wrap gap-2">
              {project.stack.map((s) => (
                <Badge key={s}>{s}</Badge>
              ))}
            </div>
          </GlassCard>
        ))}
      </div>
      {loading && (
        <p className="text-text-dim text-xs mt-4">Loading latest projects…</p>
      )}
    </section>
  );
}
