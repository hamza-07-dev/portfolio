import Badge from "../ui/Badge";

const stack = ["React", "Laravel", "Node.js", "Python", "MySQL", "PostgreSQL", "n8n", "Git"];

export default function About() {
  return (
    <section id="about" className="max-w-[1200px] mx-auto px-6 py-24 grid md:grid-cols-2 gap-12">
      <div>
        <span className="text-xs font-medium tracking-wider text-blue">ABOUT ME</span>
        <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">Who I am</h2>
        <p className="text-text-muted leading-relaxed">
          I'm a full stack developer specialized in web platforms and AI-driven
          automation. Trained as a specialized technician in digital development
          (Full Stack) at ISTA Taza, I build complete products — from database
          design to responsive interfaces — and connect them to intelligent
          workflows using n8n and prompt engineering.
        </p>
      </div>
      <div>
        <span className="text-xs font-medium tracking-wider text-purple">TECH STACK</span>
        <div className="flex flex-wrap gap-2 mt-4">
          {stack.map((tech) => (
            <Badge key={tech}>{tech}</Badge>
          ))}
        </div>
      </div>
    </section>
  );
}
