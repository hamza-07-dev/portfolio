import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import GlassCard from "../ui/GlassCard";

const FALLBACK_SKILLS = [
  { id: "react", name: "React", level: 90 },
  { id: "node", name: "Node.js / Express", level: 85 },
  { id: "laravel", name: "PHP / Laravel", level: 85 },
  { id: "python", name: "Python", level: 75 },
  { id: "sql", name: "MySQL / PostgreSQL", level: 80 },
  { id: "n8n", name: "n8n (automation)", level: 80 },
];

export default function Skills() {
  const [skills, setSkills] = useState(FALLBACK_SKILLS);

  useEffect(() => {
    api
      .getSkills()
      .then((data) => {
        if (data && data.length > 0) setSkills(data);
      })
      .catch(() => {});
  }, []);

  return (
    <section id="skills" className="max-w-[1200px] mx-auto px-6 py-24">
      <span className="text-xs font-medium tracking-wider text-purple">BENCHMARKS</span>
      <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-10">Mastery & Standards</h2>

      <GlassCard className="space-y-5">
        {skills.map((skill) => (
          <div key={skill.id || skill.name}>
            <div className="flex justify-between text-sm mb-1.5">
              <span className="font-medium">{skill.name}</span>
              <span className="text-blue font-semibold">{skill.level}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-surface overflow-hidden">
              <div
                className="h-full bg-brand-gradient rounded-full transition-all duration-700"
                style={{ width: `${skill.level}%` }}
              />
            </div>
          </div>
        ))}
      </GlassCard>
    </section>
  );
}
