import { lazy, Suspense } from "react";
import Button from "../ui/Button";

const HeroScene = lazy(() => import("../three/HeroScene"));

export default function Hero() {
  return (
    <section className="max-w-[1200px] mx-auto px-6 pt-40 pb-24 grid md:grid-cols-2 gap-12 items-center">
      <div>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface border border-border text-xs text-text-muted mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-blue animate-pulse" />
          Available for freelance projects
        </div>
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-4">
          Hamza —{" "}
          <span className="gradient-text">Full Stack Developer</span>
        </h1>
        <p className="text-lg text-text-muted mb-10 max-w-md">
          Building web platforms & AI automation solutions.
        </p>
        <div className="flex flex-wrap gap-4">
          <Button as="a" href="#projects" variant="primary">
            View Projects
          </Button>
          <Button as="a" href="#contact" variant="secondary">
            Contact Me
          </Button>
        </div>
      </div>

      <div className="relative h-[380px] md:h-[460px] rounded-card border border-border bg-surface overflow-hidden">
        <div className="absolute inset-0 bg-brand-gradient opacity-10 pointer-events-none" />
        <Suspense
          fallback={
            <div className="absolute inset-0 flex items-center justify-center text-text-dim text-sm">
              Loading scene…
            </div>
          }
        >
          <HeroScene />
        </Suspense>
      </div>
    </section>
  );
}
