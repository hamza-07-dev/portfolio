import GlassCard from "../ui/GlassCard";

const nodes = [
  { step: "01", title: "Webhook Intake", desc: "Contact form submission received by the backend API" },
  { step: "02", title: "n8n Validation", desc: "Payload checked and classified by project type" },
  { step: "03", title: "Notification", desc: "Instant alert sent (Telegram / email)" },
  { step: "04", title: "Backup", desc: "Message logged to a Google Sheet as a record" },
];

export default function AIAutomation() {
  return (
    <section id="automation" className="max-w-[1200px] mx-auto px-6 py-24">
      <span className="text-xs font-medium tracking-wider text-blue">AI & AUTOMATION</span>
      <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">
        Autonomous Workflow Pipelines
      </h2>
      <p className="text-text-muted max-w-xl mb-10">
        This portfolio's own contact form is wired to a live n8n workflow —
        not a mockup. Every message triggers real automation.
      </p>

      <GlassCard>
        <div className="flex flex-col gap-3">
          {nodes.map((node, i) => (
            <div key={node.step}>
              <div className="flex items-center gap-4 p-4 rounded-xl bg-bg-elevated border border-border">
                <span className="text-blue font-display font-bold text-sm">{node.step}</span>
                <div>
                  <p className="font-medium text-sm">{node.title}</p>
                  <p className="text-text-dim text-xs mt-0.5">{node.desc}</p>
                </div>
              </div>
              {i < nodes.length - 1 && (
                <div className="w-0.5 h-4 bg-brand-gradient mx-8" />
              )}
            </div>
          ))}
        </div>
      </GlassCard>
    </section>
  );
}
