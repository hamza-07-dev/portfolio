export default function Badge({ children }) {
  return (
    <span className="px-3 py-1 rounded-full bg-surface border border-border text-xs text-text-muted hover:border-blue/50 hover:text-text transition-colors">
      {children}
    </span>
  );
}
