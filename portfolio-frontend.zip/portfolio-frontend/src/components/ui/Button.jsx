export default function Button({ children, variant = "primary", as = "button", ...props }) {
  const base =
    "inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-medium text-sm transition-all duration-200 active:scale-[0.98]";
  const variants = {
    primary:
      "bg-brand-gradient text-white hover:shadow-glow hover:-translate-y-0.5",
    secondary:
      "bg-surface border border-border text-text hover:border-blue/50 hover:-translate-y-0.5",
  };
  const Comp = as;
  return (
    <Comp className={`${base} ${variants[variant]}`} {...props}>
      {children}
    </Comp>
  );
}
